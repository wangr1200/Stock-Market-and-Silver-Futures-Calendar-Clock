# -*- coding: utf-8 -*-
import sys
import winsound
import os
import datetime
import requests
import traceback
import random
import json
import winreg
import subprocess
import shutil
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QVBoxLayout, 
                             QHBoxLayout, QGraphicsDropShadowEffect, QPushButton, 
                             QDialog, QCalendarWidget, QSlider, QCheckBox, 
                             QFormLayout, QComboBox, QColorDialog, QSystemTrayIcon, QMenu, QAction,
                             QTableWidget, QTableWidgetItem, QHeaderView, QDoubleSpinBox, QSpinBox)
from PyQt5.QtCore import Qt, QTimer, QPoint, QDate, QRect, QRectF, pyqtSignal, QObject, QSettings, QThread, pyqtSlot
from PyQt5.QtGui import QColor, QBrush, QDesktopServices, QPainter, QIcon, QPixmap, QPen, QPolygon
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QCloseEvent
from sync_alerts import sync_to_cloud

CACHE_DIR = os.path.join(os.path.expanduser("~"), ".market_clock_cache")

def get_server_key():
    key = os.getenv("SERVER_CHAN_KEY")
    if key:
        return key.strip()
    try:
        config_file = os.path.join(CACHE_DIR, "config.json")
        if os.path.exists(config_file):
            with open(config_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("server_chan_key", "").strip()
    except Exception:
        pass
    return ""

DEFAULT_AG_CONTRACT = "AG2702"
DEFAULT_AU_CONTRACT = "AU2702"
DEFAULT_AG_PRICE = 12523.0
DEFAULT_AU_PRICE = 874.6
DEFAULT_AG_MULTIPLIER = 15.0
DEFAULT_AU_MULTIPLIER = 1000.0

LOG_FILE = os.path.join(CACHE_DIR, "error.log")

def log_error(err, context_msg=""):
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 5 * 1024 * 1024:
            bak_file = os.path.join(CACHE_DIR, "error.log.bak")
            if os.path.exists(bak_file):
                os.remove(bak_file)
            os.rename(LOG_FILE, bak_file)

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{now_str}] ERROR in {context_msg}:\n")
            f.write(f"Type: {type(err).__name__} | Message: {str(err)}\n")
            f.write("Traceback:\n" + traceback.format_exc() + "\n")
            f.write("-" * 60 + "\n")
    except Exception:
        pass

def cleanup_cache():
    try:
        if not os.path.exists(CACHE_DIR):
            return
        now_ts = datetime.datetime.now().timestamp()
        expire_seconds = 30 * 24 * 3600
        for filename in os.listdir(CACHE_DIR):
            filepath = os.path.join(CACHE_DIR, filename)
            if os.path.isfile(filepath) and not filename.endswith("error.log"):
                if now_ts - os.path.getmtime(filepath) > expire_seconds:
                    try:
                        os.remove(filepath)
                    except Exception:
                        pass
    except Exception as e:
        log_error(e, "CleanupCache")

def check_is_market_open(now=None, market_type="AG"):
    if now is None:
        now = datetime.datetime.now()
    weekday = now.weekday()
    t = now.time()
    if weekday == 5 and t <= datetime.time(2, 30) and market_type == "AG":
        return True
    if weekday >= 5:
        return False
    date_key = now.strftime("%Y-%m-%d")
    if date_key in HOLIDAY_SCHEDULE:
        info = HOLIDAY_SCHEDULE[date_key]
        market_hours = info.get("market_hours", {})
        if market_type in market_hours:
            intervals = market_hours[market_type]
            for itv in intervals:
                o_h, o_m = map(int, itv["open"].split(":"))
                c_h, c_m = map(int, itv["close"].split(":"))
                if datetime.time(o_h, o_m) <= t <= datetime.time(c_h, c_m):
                    return True
            return False
        types = info.get("types", []) if isinstance(info, dict) else info
        if market_type in types:
            return False
    if market_type == "AG":
        if (datetime.time(9, 0) <= t <= datetime.time(11, 30)) or \
           (datetime.time(13, 30) <= t <= datetime.time(15, 0)) or \
           (t >= datetime.time(21, 0) or t <= datetime.time(2, 30)):
            return True
    elif market_type == "A":
        if (datetime.time(9, 30) <= t <= datetime.time(11, 30)) or \
           (datetime.time(13, 0) <= t <= datetime.time(15, 0)):
            return True
    elif market_type == "HK":
        if (datetime.time(9, 30) <= t <= datetime.time(12, 0)) or \
           (datetime.time(13, 0) <= t <= datetime.time(16, 0)):
            return True
    return False

REG_PATH = r"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
APP_NAME = "MarketDesktopClock"

def set_autostart(enable=True):
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_ALL_ACCESS)
        if enable:
            app_path = os.path.abspath(sys.argv[0])
            if app_path.endswith(".py"):
                cmd = f'"{sys.executable}" "{app_path}"'
            else:
                cmd = f'"{app_path}"'
            winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, cmd)
        else:
            try:
                winreg.DeleteValue(key, APP_NAME)
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
        return True
    except Exception as e:
        return False

def check_autostart():
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_READ)
        winreg.QueryValueEx(key, APP_NAME)
        winreg.CloseKey(key)
        return True
    except Exception:
        return False

COLOR_THEMES = {
    "天蓝色 (默认极客)": {"bg_color": "#1e222b", "time_color": "#38bdf8", "card_bg": "#262b36", "accent": "#0284c7"},
    "炫酷暗黑 (Cool Black)": {"bg_color": "#121212", "time_color": "#f43f5e", "card_bg": "#1e1e1e", "accent": "#e11d48"},
    "翡翠森林 (Emerald Green)": {"bg_color": "#064e3b", "time_color": "#34d399", "card_bg": "#047857", "accent": "#059669"},
    "紫罗兰 (Midnight Violet)": {"bg_color": "#2e1065", "time_color": "#c084fc", "card_bg": "#3b0764", "accent": "#9333ea"},
    "浪漫樱粉 (Sakura Pink)": {"bg_color": "#831843", "time_color": "#f472b6", "card_bg": "#9d174d", "accent": "#db2777"},
    "琥珀烫金 (Warm Amber)": {"bg_color": "#451a03", "time_color": "#fbbf24", "card_bg": "#78350f", "accent": "#d97706"}
}

MACRO_EVENTS = [
    {"name": "10月 CPI数据 (11/12公布)", "time": datetime.datetime(2026, 11, 12, 21, 30)},
    {"name": "11月 非农报告 (12/04公布)", "time": datetime.datetime(2026, 12, 4, 21, 30)},
    {"name": "12月 FOMC 议息会议 (12/10)", "time": datetime.datetime(2026, 12, 10, 3, 0)},
    {"name": "11月 CPI数据 (12/10公布)", "time": datetime.datetime(2026, 12, 10, 21, 30)},
    {"name": "12月 非农报告 (01/08公布)", "time": datetime.datetime(2027, 1, 8, 21, 30)},
    {"name": "2027年1月 议息会议 (01/28)", "time": datetime.datetime(2027, 1, 28, 3, 0)},
]

HOLIDAY_SCHEDULE = {
    "2026-01-01": {"types": ["A", "HK", "AG"], "reason": "元旦休市"},
    "2026-02-16": {"types": ["A", "HK", "AG"], "reason": "春节假期休市"},
    "2026-10-01": {"types": ["A", "HK", "AG"], "reason": "国庆节休市"},
    "2027-01-01": {"types": ["A", "HK", "AG"], "reason": "元旦休市"},
}

class SilentTipDialog(QDialog):
    def __init__(self, title, message, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(320, 160)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        container = QWidget(self)
        container.setStyleSheet("QWidget { background-color: #1e222b; border-radius: 12px; border: 1px solid rgba(56, 189, 248, 0.3); }")
        
        layout = QVBoxLayout(container)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(12)
        
        title_lbl = QLabel("🔔 " + title)
        title_lbl.setStyleSheet("color: #38bdf8; font-size: 15px; font-weight: bold; border: none; background: transparent;")
        layout.addWidget(title_lbl)
        
        msg_lbl = QLabel(message)
        msg_lbl.setWordWrap(True)
        msg_lbl.setStyleSheet("color: #e2e8f0; font-size: 13px; border: none; background: transparent;")
        layout.addWidget(msg_lbl)
        
        ok_btn = QPushButton("确定")
        ok_btn.setStyleSheet("QPushButton { background-color: #0284c7; color: white; border-radius: 6px; padding: 6px 16px; font-weight: bold; border: none; } QPushButton:hover { background-color: #0369a1; }")
        ok_btn.clicked.connect(self.accept)
        
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        layout.addLayout(btn_layout)
        main_layout.addWidget(container)

class AddPriceAlertDialog(QDialog):
    def __init__(self, current_contract="AG2702", current_price=12500.0, parent=None):
        super().__init__(parent)
        self.setWindowTitle("添加价格预警")
        self.resize(340, 240)
        self.setStyleSheet("background-color: #1e222b; color: white;")
        self.parent_window = parent
        self.default_contract = current_contract
        self.current_price = current_price
        self.result_data = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        title = QLabel("🎯 设置合约价格预警")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #38bdf8; margin-bottom: 6px;")
        layout.addWidget(title)

        form = QFormLayout()
        self.contract_combo = QComboBox()
        ag_c = getattr(self.parent_window, 'ag_contract', 'AG2702') if self.parent_window else "AG2702"
        au_c = getattr(self.parent_window, 'au_contract', 'AU2702') if self.parent_window else "AU2702"
        self.contract_combo.addItems([f"沪银 ({ag_c})", f"沪金 ({au_c})"])
        form.addRow("选择合约:", self.contract_combo)

        self.cond_combo = QComboBox()
        self.cond_combo.addItems(["合约价格涨到 (≥)", "合约价格跌到 (≤)"])
        form.addRow("预警条件:", self.cond_combo)

        self.price_spin = QDoubleSpinBox()
        self.price_spin.setRange(1.0, 999999.0)
        self.price_spin.setDecimals(1)
        self.price_spin.setValue(self.current_price)
        form.addRow("目标价格:", self.price_spin)

        layout.addLayout(form)
        
        btn_layout = QHBoxLayout()
        ok_btn = QPushButton("确定添加")
        ok_btn.setStyleSheet("background-color: #0284c7; color: white; border-radius: 5px; padding: 7px 16px; font-weight: bold;")
        ok_btn.clicked.connect(self.accept)
        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        layout.addLayout(btn_layout)

class PriceAlertDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        self.setWindowTitle("价格预警管理")
        self.resize(480, 320)
        self.setStyleSheet("background-color: #1e222b; color: white;")
        layout = QVBoxLayout(self)
        
        top_row = QHBoxLayout()
        title = QLabel("🔔 涨跌目标位预警中心")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #38bdf8;")
        top_row.addWidget(title)
        top_row.addStretch()
        
        self.sync_cloud_btn = QPushButton("☁️ 同步到云端")
        self.sync_cloud_btn.setStyleSheet("QPushButton { background-color: #059669; color: white; border-radius: 4px; padding: 5px 12px; font-weight: bold; font-size: 12px; } QPushButton:hover { background-color: #10b981; }")
        self.sync_cloud_btn.clicked.connect(self.sync_alerts_to_cloud)
        top_row.addWidget(self.sync_cloud_btn)
        layout.addLayout(top_row)
        
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["合约", "预警条件", "目标价格", "状态"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)
        
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def sync_alerts_to_cloud(self):
        try:
            success, msg = sync_to_cloud()
            if success:
                dlg = SilentTipDialog("☁️ 云端同步成功", "预警配置已成功同步到云端！", self)
            else:
                dlg = SilentTipDialog("❌ 同步提示", msg, self)
            dlg.exec_()
        except Exception as e:
            dlg = SilentTipDialog("❌ 同步异常", str(e), self)
            dlg.exec_()

class MiniTrendChartWidget(QWidget):
    period_changed = pyqtSignal(int)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(140)

class ClockWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.current_commodity = "沪银"
        self.ag_contract = "AG2702"
        self.au_contract = "AU2702"
        self.silver_data = {"contract": "AG2702", "price": "12523.0", "change": "-52.0", "change_pct": "-0.41%"}
        self.saved_calc_params = {"dir_idx": 1, "open_price": 12375.0, "lots": 1, "comm_rate": 0.0020}
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("MarketDesktopClock - 市场行情桌面时钟")
        self.resize(340, 620)
        self.setStyleSheet("background-color: #1e222b; color: white;")
        
        main_layout = QVBoxLayout(self)
        
        title_lbl = QLabel("🕒 市场行情桌面时钟")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #38bdf8;")
        main_layout.addWidget(title_lbl)

        self.time_label = QLabel("21:29:27")
        self.time_label.setStyleSheet("font-size: 32px; font-weight: bold; color: #ffffff;")
        self.time_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(self.time_label)

        self.status_label = QLabel("● 白银期货：交易中 (Live) | 价格: 12523.0")
        self.status_label.setStyleSheet("font-size: 12px; color: #22c55e;")
        main_layout.addWidget(self.status_label)

        self.trend_chart = MiniTrendChartWidget(self)
        main_layout.addWidget(self.trend_chart)

        btn_row = QHBoxLayout()
        alert_btn = QPushButton("🔔 价格预警")
        alert_btn.clicked.connect(lambda: PriceAlertDialog(self).exec_())
        btn_row.addWidget(alert_btn)
        
        close_btn = QPushButton("退出")
        close_btn.clicked.connect(self.close)
        btn_row.addWidget(close_btn)
        main_layout.addLayout(btn_row)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = ClockWindow()
    w.show()
    sys.exit(app.exec_())
