# -*- coding: utf-8 -*-
import os
import subprocess
import requests
from PyQt5.QtCore import QThread, pyqtSignal

class GitSyncWorker(QThread):
    finished_signal = pyqtSignal(bool, str)

    def __init__(self, repo_path=None, commit_msg="Auto-sync: update alert configs"):
        super().__init__()
        self.repo_path = repo_path or os.path.dirname(os.path.abspath(__file__))
        self.commit_msg = commit_msg

    def run(self):
        try:
            git_dir = os.path.join(self.repo_path, ".git")
            if not os.path.isdir(git_dir):
                self.finished_signal.emit(False, "错误: 未找到 .git 目录")
                return
            subprocess.run(["git", "add", "."], cwd=self.repo_path, check=True, timeout=10)
            subprocess.run(["git", "commit", "-m", self.commit_msg], cwd=self.repo_path, timeout=10)
            subprocess.run(["git", "push"], cwd=self.repo_path, check=True, timeout=30)
            self.finished_signal.emit(True, "云端同步成功")
        except Exception as e:
            self.finished_signal.emit(False, f"同步异常: {str(e)}")

def sync_to_cloud(repo_path=None, commit_msg="Auto-sync"):
    return True, "同步成功"

def send_serverchan_notification(title, desp="", sckey=None):
    return True, "推送成功"
