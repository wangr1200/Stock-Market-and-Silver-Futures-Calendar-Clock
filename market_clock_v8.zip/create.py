# -*- coding: utf-8 -*-
import sys
import winsound
import os
import datetime
import requests
import traceback
import random
import json
import winreg
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QVBoxLayout, 
                             QHBoxLayout, QGraphicsDropShadowEffect, QPushButton, 
                             QDialog, QCalendarWidget, QSlider, QCheckBox, 
                             QFormLayout, QComboBox, QColorDialog, QSystemTrayIcon, QMenu, QAction,
                             QTableWidget, QTableWidgetItem, QHeaderView, QDoubleSpinBox, QSpinBox)
from PyQt5.QtCore import Qt, QTimer, QPoint, QDate, QRect, QRectF, pyqtSignal, QObject, QThread, pyqtSlot
from PyQt5.QtGui import QColor, QBrush, QPainter, QIcon, QPixmap, QPen

CACHE_DIR = os.path.join(os.path.expanduser("~"), ".market_clock_cache")

def log_error(err, context_msg=""):
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        log_file = os.path.join(CACHE_DIR, "error.log")
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"[{now_str}] ERROR in {context_msg}:\n{str(err)}\n")
    except Exception:
        pass

def check_is_market_open(now=None, market_type="AG"):
    if now is None:
        now = datetime.datetime.now()
    weekday = now.weekday()
    t = now.time()
    if weekday == 5 and t <= datetime.time(2, 30) and market_type == "AG":
        return True
    if weekday >= 5:
        return False
    return True

class SilentTipDialog(QDialog):
    def __init__(self, title, message, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(320, 160)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        container = QWidget(self)
        container.setStyleSheet("background-color: #1e222b; border-radius: 12px; border: 1px solid rgba(56, 189, 248, 0.3);")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(20, 18, 20, 18)
        
        title_lbl = QLabel("🔔 " + title)
        title_lbl.setStyleSheet("color: #38bdf8; font-size: 15px; font-weight: bold; border: none; background: transparent;")
        layout.addWidget(title_lbl)

        msg_lbl = QLabel(message)
        msg_lbl.setWordWrap(True)
        msg_lbl.setStyleSheet("color: #e2e8f0; font-size: 13px; border: none; background: transparent;")
        layout.addWidget(msg_lbl)

        ok_btn = QPushButton("确定")
        ok_btn.setStyleSheet("background-color: #0284c7; color: white; border-radius: 6px; padding: 6px 16px; font-weight: bold;")
        ok_btn.clicked.connect(self.accept)
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        layout.addLayout(btn_layout)
        main_layout.addWidget(container)


class ProfitLossCalculatorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        self.setWindowTitle("实时盈亏计算器")
        self.resize(360, 380)
        self.setStyleSheet("background-color: #1e222b; color: white;")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        title = QLabel("🧮 实时持仓盈亏与佣金计算器")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #38bdf8;")
        layout.addWidget(title)

        form = QFormLayout()
        form.setSpacing(8)

        self.dir_combo = QComboBox()
        self.dir_combo.addItems(["做多 (Buy Long)", "做空 (Sell Short)"])
        self.dir_combo.setStyleSheet("QComboBox { background-color: #262b36; color: #38bdf8; font-weight: bold; border: 1px solid #475569; border-radius: 4px; padding: 4px; font-size: 12px; }")
        
        if self.parent_window and hasattr(self.parent_window, 'saved_calc_params'):
            self.dir_combo.setCurrentIndex(self.parent_window.saved_calc_params.get("dir_idx", 1))
        self.dir_combo.currentIndexChanged.connect(self.on_param_changed)
        form.addRow("多空头寸:", self.dir_combo)

        comm_type = getattr(self.parent_window, 'current_commodity', '沪银') if self.parent_window else '沪银'
        base_default = 874.6 if comm_type == "沪金" else 12523.0

        saved_p = base_default
        if self.parent_window and hasattr(self.parent_window, 'saved_calc_params'):
            saved_p = self.parent_window.saved_calc_params.get("open_price", base_default)

        self.open_price_spin = QDoubleSpinBox()
        self.open_price_spin.setRange(0.1, 999999.0)
        self.open_price_spin.setDecimals(1)
        self.open_price_spin.setValue(saved_p)
        self.open_price_spin.setStyleSheet("QDoubleSpinBox { background-color: #262b36; color: #ffffff; font-weight: bold; border: 1px solid #475569; border-radius: 4px; padding: 4px; font-size: 12px; }")
        self.open_price_spin.valueChanged.connect(self.on_param_changed)
        form.addRow("开仓价格:", self.open_price_spin)

        saved_lots = 1
        if self.parent_window and hasattr(self.parent_window, 'saved_calc_params'):
            saved_lots = self.parent_window.saved_calc_params.get("lots", 1)

        self.lots_spin = QSpinBox()
        self.lots_spin.setRange(1, 10000)
        self.lots_spin.setValue(saved_lots)
        self.lots_spin.setStyleSheet("QSpinBox { background-color: #262b36; color: #ffffff; font-weight: bold; border: 1px solid #475569; border-radius: 4px; padding: 4px; font-size: 12px; }")
        self.lots_spin.valueChanged.connect(self.on_param_changed)
        form.addRow("持仓手数:", self.lots_spin)

        saved_comm = 0.0020
        if self.parent_window and hasattr(self.parent_window, 'saved_calc_params'):
            saved_comm = self.parent_window.saved_calc_params.get("comm_rate", 0.0020)

        self.comm_spin = QDoubleSpinBox()
        self.comm_spin.setRange(0.0, 1.0)
        self.comm_spin.setDecimals(4)
        self.comm_spin.setSingleStep(0.001)
        self.comm_spin.setValue(saved_comm)
        self.comm_spin.setSuffix("%")
        self.comm_spin.setStyleSheet("QDoubleSpinBox { background-color: #262b36; color: #38bdf8; font-weight: bold; border: 1px solid #475569; border-radius: 4px; padding: 4px; font-size: 12px; }")
        self.comm_spin.valueChanged.connect(self.on_param_changed)
        form.addRow("单边佣金费率:", self.comm_spin)

        layout.addLayout(form)

        self.result_card = QWidget()
        self.result_card.setStyleSheet("background-color: #141820; border-radius: 8px; border: 1px solid rgba(56, 189, 248, 0.2);")
        card_layout = QVBoxLayout(self.result_card)
        card_layout.setContentsMargins(12, 8, 12, 8)
        card_layout.setSpacing(4)

        self.pnl_title_lbl = QLabel("扣除来回佣金后净盈亏")
        self.pnl_title_lbl.setStyleSheet("color: #94a3b8; font-size: 11px; border: none;")
        self.pnl_title_lbl.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(self.pnl_title_lbl)

        self.pnl_val_lbl = QLabel("+0.0 元")
        self.pnl_val_lbl.setStyleSheet("color: #ef4444; font-size: 18px; font-weight: bold; border: none;")
        self.pnl_val_lbl.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(self.pnl_val_lbl)

        self.comm_fee_lbl = QLabel("来回佣金: 0.0 元")
        self.comm_fee_lbl.setStyleSheet("color: #facc15; font-size: 11px; border: none;")
        self.comm_fee_lbl.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(self.comm_fee_lbl)

        self.info_lbl = QLabel("当前现价: --")
        self.info_lbl.setStyleSheet("color: #64748b; font-size: 10px; border: none;")
        self.info_lbl.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(self.info_lbl)

        layout.addWidget(self.result_card)

        save_close_btn = QPushButton("保存并关闭窗口")
        save_close_btn.setStyleSheet("background-color: #0284c7; color: white; border-radius: 5px; padding: 7px; font-weight: bold;")
        save_close_btn.clicked.connect(self.on_save_and_close)
        layout.addWidget(save_close_btn)

        self.calculate()

    def on_param_changed(self):
        self.calculate()
        self.save_current_params()

    def calculate(self):
        try:
            curr_p = 12523.0
            comm_type = "沪银"
            if self.parent_window and hasattr(self.parent_window, 'silver_data'):
                curr_p = float(self.parent_window.silver_data.get('price', 12523.0))
                comm_type = getattr(self.parent_window, 'current_commodity', '沪银')

            mult = 15.0 if comm_type == "沪银" else 1000.0
            open_p = self.open_price_spin.value()
            lots = self.lots_spin.value()
            is_long = (self.dir_combo.currentIndex() == 0)

            diff = (curr_p - open_p) if is_long else (open_p - curr_p)
            gross_pnl = diff * mult * lots

            single_rate = self.comm_spin.value() / 100.0
            round_rate = single_rate * 2.0
            turnover = (open_p + curr_p) * mult * lots
            total_commission = turnover * single_rate
            net_pnl = gross_pnl - total_commission

            self.info_lbl.setText(f"当前{comm_type}现价: {curr_p}  |  乘数: {int(mult)}")
            self.comm_fee_lbl.setText(f"来回佣金扣除: -{total_commission:.1f} 元 (双边费率: {round_rate*100:.3f}%)")

            if net_pnl >= 0:
                self.pnl_val_lbl.setText(f"净浮盈: +{net_pnl:,.1f} 元")
                self.pnl_val_lbl.setStyleSheet("color: #ef4444; font-size: 18px; font-weight: bold; border: none;")
            else:
                self.pnl_val_lbl.setText(f"净浮亏: {net_pnl:,.1f} 元")
                self.pnl_val_lbl.setStyleSheet("color: #22c55e; font-size: 18px; font-weight: bold; border: none;")
        except Exception:
            pass

    def save_current_params(self):
        if self.parent_window:
            self.parent_window.saved_calc_params = {
                "dir_idx": self.dir_combo.currentIndex(),
                "open_price": self.open_price_spin.value(),
                "lots": self.lots_spin.value(),
                "comm_rate": self.comm_spin.value()
            }
            self.parent_window.update_compact_pnl()
            self.parent_window.save_settings()

    def on_save_and_close(self):
        self.save_current_params()
        self.accept()


class ClockWindow(QWidget):
    def load_settings(self):
        settings_file = os.path.join(CACHE_DIR, "config.json")
        data = {}
        if os.path.exists(settings_file):
            try:
                with open(settings_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                pass
        
        self.saved_calc_params = {
            "dir_idx": data.get("calc_dir_idx", 1),
            "open_price": data.get("calc_open_price", 12523.0),
            "lots": data.get("calc_lots", 1),
            "comm_rate": data.get("calc_comm_rate", 0.0020)
        }

    def save_settings(self):
        settings_file = os.path.join(CACHE_DIR, "config.json")
        data = {
            "calc_dir_idx": self.saved_calc_params.get("dir_idx", 1),
            "calc_open_price": self.saved_calc_params.get("open_price", 12523.0),
            "calc_lots": self.saved_calc_params.get("lots", 1),
            "calc_comm_rate": self.saved_calc_params.get("comm_rate", 0.0020)
        }
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            with open(settings_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def __init__(self):
        super().__init__()
        self.load_settings()
        self.is_locked = False
        self.is_quitting = False
        self.current_commodity = "沪银"
        self.silver_data = {"contract": "AG2702", "price": "12523.0", "change": "-52.0", "change_pct": "-0.41%", "open_interest": "242022"}

        self.init_ui()

    def init_ui(self):
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowOpacity(0.95)

        self.container = QWidget(self)
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(6, 6, 6, 6)
        main_layout.addWidget(self.container)

        c_layout = QVBoxLayout(self.container)
        c_layout.setContentsMargins(16, 12, 16, 16)
        c_layout.setSpacing(8)

        top_bar = QHBoxLayout()
        self.calc_btn = QPushButton("🧮")
        self.calc_btn.clicked.connect(self.open_calculator)
        top_bar.addWidget(self.calc_btn)
        top_bar.addStretch()
        c_layout.addLayout(top_bar)

        self.time_label = QLabel("21:29:27")
        c_layout.addWidget(self.time_label)

        # ===== 紧凑盈亏结果展示卡片（包含开仓价） =====
        self.compact_pnl_card = QWidget()
        self.compact_pnl_card.setStyleSheet("background-color: #141820; border-radius: 8px; border: 1px solid rgba(56, 189, 248, 0.3);")
        compact_layout = QVBoxLayout(self.compact_pnl_card)
        compact_layout.setContentsMargins(10, 8, 10, 8)
        compact_layout.setSpacing(4)

        self.compact_pnl_val_lbl = QLabel("净浮盈: +0.0 元")
        self.compact_pnl_val_lbl.setStyleSheet("color: #ef4444; font-size: 16px; font-weight: bold; border: none; background: transparent;")
        self.compact_pnl_val_lbl.setAlignment(Qt.AlignCenter)
        compact_layout.addWidget(self.compact_pnl_val_lbl)

        self.compact_open_lbl = QLabel()
        self.compact_open_lbl.setStyleSheet("color: #38bdf8; font-size: 12px; font-weight: bold; border: none; background: transparent;")
        self.compact_open_lbl.setAlignment(Qt.AlignCenter)
        compact_layout.addWidget(self.compact_open_lbl)

        self.compact_comm_lbl = QLabel()
        self.compact_comm_lbl.setStyleSheet("color: #facc15; font-size: 11px; font-weight: bold; border: none; background: transparent;")
        self.compact_comm_lbl.setAlignment(Qt.AlignCenter)
        compact_layout.addWidget(self.compact_comm_lbl)

        c_layout.addWidget(self.compact_pnl_card)
        self.update_compact_pnl()
        self.resize(340, 400)

    def update_compact_pnl(self):
        try:
            curr_p = float(self.silver_data.get('price', 12523.0))
            p_data = getattr(self, 'saved_calc_params', {"dir_idx": 1, "open_price": curr_p, "lots": 1, "comm_rate": 0.0020})
            open_p = p_data.get("open_price", curr_p)
            lots = p_data.get("lots", 1)
            dir_idx = p_data.get("dir_idx", 1)
            is_long = (dir_idx == 0)

            dir_str = "多头" if is_long else "空头"
            if hasattr(self, 'compact_open_lbl'):
                self.compact_open_lbl.setText(f"📌 {dir_str}开仓价: {open_p:.1f}  ({lots}手)")

            mult = 15.0 if self.current_commodity == "沪银" else 1000.0
            diff = (curr_p - open_p) if is_long else (open_p - curr_p)
            gross_pnl = diff * mult * lots

            single_rate = p_data.get("comm_rate", 0.0020) / 100.0
            round_rate = single_rate * 2.0
            turnover = (open_p + curr_p) * mult * lots
            total_commission = turnover * single_rate
            net_pnl = gross_pnl - total_commission

            if hasattr(self, 'compact_comm_lbl'):
                self.compact_comm_lbl.setText(f"来回佣金扣除: -{total_commission:.1f} 元 (双边费率: {round_rate*100:.3f}%)")

            if hasattr(self, 'compact_pnl_val_lbl'):
                if net_pnl >= 0:
                    self.compact_pnl_val_lbl.setText(f"净浮盈: +{net_pnl:,.1f} 元")
                    self.compact_pnl_val_lbl.setStyleSheet("color: #ef4444; font-size: 15px; font-weight: bold; border: none; background: transparent;")
                else:
                    self.compact_pnl_val_lbl.setText(f"净浮亏: {net_pnl:,.1f} 元")
                    self.compact_pnl_val_lbl.setStyleSheet("color: #22c55e; font-size: 15px; font-weight: bold; border: none; background: transparent;")
        except Exception:
            pass

    def open_calculator(self):
        dlg = ProfitLossCalculatorDialog(self)
        if dlg.exec_() == QDialog.Accepted:
            self.update_compact_pnl()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ClockWindow()
    window.show()
    sys.exit(app.exec_())
