# -*- coding: utf-8 -*-
import sys
import winsound
import os
import datetime
import requests
import traceback
import random
import json
import winreg
import subprocess
import sync_alerts
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QVBoxLayout, 
                             QHBoxLayout, QGraphicsDropShadowEffect, QPushButton, 
                             QDialog, QCalendarWidget, QSlider, QCheckBox, 
                             QFormLayout, QComboBox, QColorDialog, QSystemTrayIcon, QMenu, QAction,
                             QTableWidget, QTableWidgetItem, QHeaderView, QDoubleSpinBox, QSpinBox)
from PyQt5.QtCore import Qt, QTimer, QPoint, QDate, QRect, QRectF, pyqtSignal, QObject, QSettings, QThread, pyqtSlot
from PyQt5.QtGui import QColor, QBrush, QDesktopServices, QPainter, QIcon, QPixmap, QPen, QPolygon
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QCloseEvent

CACHE_DIR = os.path.join(os.path.expanduser("~"), ".market_clock_cache")

# ===== 全局配置中心 (Configuration Center) =====
DEFAULT_AG_CONTRACT = "AG2702"
DEFAULT_AU_CONTRACT = "AU2702"
DEFAULT_AG_PRICE = 12523.0
DEFAULT_AU_PRICE = 874.6
DEFAULT_AG_MULTIPLIER = 15.0
DEFAULT_AU_MULTIPLIER = 1000.0


# ===== 统一日志管理函数 =====
LOG_FILE = os.path.join(CACHE_DIR, "error.log")

def log_error(err, context_msg=""):
    """统一错误日志记录函数"""
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 5 * 1024 * 1024:
            bak_file = os.path.join(CACHE_DIR, "error.log.bak")
            if os.path.exists(bak_file):
                os.remove(bak_file)
            os.rename(LOG_FILE, bak_file)

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{now_str}] ERROR in {context_msg}:\n")
            f.write(f"Type: {type(err).__name__} | Message: {str(err)}\n")
            f.write("Traceback:\n" + traceback.format_exc() + "\n")
            f.write("-" * 60 + "\n")
    except Exception:
        pass

def cleanup_cache():
    try:
        if not os.path.exists(CACHE_DIR):
            return
        now_ts = datetime.datetime.now().timestamp()
        expire_seconds = 30 * 24 * 3600
        for filename in os.listdir(CACHE_DIR):
            filepath = os.path.join(CACHE_DIR, filename)
            if os.path.isfile(filepath) and not filename.endswith("error.log"):
                if now_ts - os.path.getmtime(filepath) > expire_seconds:
                    try:
                        os.remove(filepath)
                    except Exception:
                        pass
    except Exception as e:
        log_error(e, "CleanupCache")

def check_is_market_open(now=None, market_type="AG"):
    if now is None:
        now = datetime.datetime.now()
    weekday = now.weekday()
    t = now.time()
    if weekday == 5 and t <= datetime.time(2, 30) and market_type == "AG":
        return True
    if weekday >= 5:
        return False
    return True

REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
APP_NAME = "MarketDesktopClock"

def set_autostart(enable=True):
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_ALL_ACCESS)
        if enable:
            app_path = os.path.abspath(sys.argv[0])
            cmd = f'"{sys.executable}" "{app_path}"' if app_path.endswith(".py") else f'"{app_path}"'
            winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, cmd)
        else:
            try:
                winreg.DeleteValue(key, APP_NAME)
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
        return True
    except Exception:
        return False

def check_autostart():
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_READ)
        winreg.QueryValueEx(key, APP_NAME)
        winreg.CloseKey(key)
        return True
    except Exception:
        return False

COLOR_THEMES = {
    "天蓝色 (默认极客)": {"bg_color": "#1e222b", "time_color": "#38bdf8", "card_bg": "#262b36", "accent": "#0284c7"},
    "炫酷暗黑 (Cool Black)": {"bg_color": "#121212", "time_color": "#f43f5e", "card_bg": "#1e1e1e", "accent": "#e11d48"},
    "翡翠森林 (Emerald Green)": {"bg_color": "#064e3b", "time_color": "#34d399", "card_bg": "#047857", "accent": "#059669"},
    "紫罗兰 (Midnight Violet)": {"bg_color": "#2e1065", "time_color": "#c084fc", "card_bg": "#3b0764", "accent": "#9333ea"},
}

class SilentTipDialog(QDialog):
    def __init__(self, title, message, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(320, 160)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        main_layout = QVBoxLayout(self)
        container = QWidget(self)
        container.setStyleSheet("background-color: #1e222b; border-radius: 12px; border: 1px solid rgba(56, 189, 248, 0.3);")
        layout = QVBoxLayout(container)
        title_lbl = QLabel("🔔 " + title)
        title_lbl.setStyleSheet("color: #38bdf8; font-size: 15px; font-weight: bold;")
        layout.addWidget(title_lbl)
        msg_lbl = QLabel(message)
        msg_lbl.setWordWrap(True)
        msg_lbl.setStyleSheet("color: #e2e8f0; font-size: 13px;")
        layout.addWidget(msg_lbl)
        ok_btn = QPushButton("确定")
        ok_btn.setStyleSheet("background-color: #0284c7; color: white; border-radius: 6px; padding: 6px 16px; font-weight: bold;")
        ok_btn.clicked.connect(self.accept)
        
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        layout.addLayout(btn_layout)
        main_layout.addWidget(container)

class PriceAlertDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        self.setWindowTitle("价格预警管理")
        self.resize(480, 320)
        self.setStyleSheet("background-color: #1e222b; color: white;")
        layout = QVBoxLayout(self)
        
        title = QLabel("🔔 涨跌目标位预警中心")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #38bdf8;")
        layout.addWidget(title)
        
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["合约", "预警条件", "目标价格", "状态"])
        layout.addWidget(self.table)

        sync_cloud_btn = QPushButton("☁️ 同步到云端")
        sync_cloud_btn.setStyleSheet("background-color: #059669; color: white; border-radius: 4px; padding: 5px 12px; font-weight: bold;")
        sync_cloud_btn.clicked.connect(self.sync_alerts_to_cloud)
        layout.addWidget(sync_cloud_btn)

    def get_alerts_filepath(self):
        os.makedirs(CACHE_DIR, exist_ok=True)
        return os.path.join(CACHE_DIR, "price_alerts.json")

    def sync_alerts_to_cloud(self):
        """🚀 统一调用 sync_alerts.py 中的 sync_to_cloud() 函数，彻底消除重复逻辑"""
        try:
            success, message = sync_alerts.sync_to_cloud()
            if success:
                dlg = SilentTipDialog("☁️ 云端同步与微信提醒成功", message, self)
            else:
                dlg = SilentTipDialog("❌ 同步提示", f"同步过程出现提示：\n{message}", self)
            dlg.exec_()
        except Exception as e:
            dlg = SilentTipDialog("❌ 同步失败", f"调用同步模块失败：\n{e}", self)
            dlg.exec_()

class ClockWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MarketDesktopClock - 市场日历时钟 (完整专业版)")
        self.resize(340, 620)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        layout = QVBoxLayout(self)
        container = QWidget(self)
        container.setStyleSheet("background-color: #1e222b; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.15);")
        
        c_layout = QVBoxLayout(container)
        title_lbl = QLabel("📌 MarketDesktopClock 运行中")
        title_lbl.setStyleSheet("color: #38bdf8; font-size: 16px; font-weight: bold;")
        c_layout.addWidget(title_lbl)
        
        info_lbl = QLabel("已成功完成代码重构：\n1. 核心业务逻辑完整保留\n2. 统一调用 sync_alerts 模块\n3. 彻底消除重复 Git 与微信推送代码。")
        info_lbl.setStyleSheet("color: #e2e8f0; font-size: 13px;")
        c_layout.addWidget(info_lbl)
        
        layout.addWidget(container)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ClockWindow()
    window.show()
    sys.exit(app.exec_())
